import mongoose from 'mongoose';

// This is just a placeholder model for imports to work
const User = {};

export default User;
